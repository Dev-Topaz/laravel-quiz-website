Update slide view
